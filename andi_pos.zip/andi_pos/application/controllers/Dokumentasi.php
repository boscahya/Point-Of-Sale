<?php 
class Dokumentasi extends CI_Controller{
    
    function index(){
         $this->template->load('template','dokumentasi/list');
    }
    
    
}



?>