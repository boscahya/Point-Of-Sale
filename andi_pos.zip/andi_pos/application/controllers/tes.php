<?php
class tes extends CI_Controller{
    
    
    function index(){
        echo jam();
    }
}

?>